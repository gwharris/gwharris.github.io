import java.io.*;
import java.util.*;

/**
 * Class that performs these operations:
 * 		Creates ArrayList from files
 * 		Creates Queue from ArrayList
 * 		Prints an array (debugging purposes)
 * 		Prints the attributes of each node (debugging purposes)
 * 
 * @author grahamharris
 */
public class Operator {

	/**
	 * Reads from the BufferedReader into an Arraylist
	 * @param file The file to be split
	 * @return The ArrayList of Strings from the file
	 */
	public ArrayList<String> splitFile(BufferedReader file) {
		
		ArrayList<String> strings = new ArrayList<String>();
		
		String line;
		try {
			while ((line = file.readLine()) != null) {
				strings.add(line);
			}
		} 
		catch (IOException e) { e.printStackTrace(); }
		
		return strings;
	}
	
	/**
	 * Method that creates a LinkedList of customer nodes out of
	 * the customers ArrayList.
	 * @param strings Customers ArrayList
	 * @return LinkedList representation of customers
	 */
	public CQueue<CNode> makeQueue(ArrayList<String> strings) {
		
		CQueue<CNode> queue = new CQueue<CNode>();
		
		// Get the wait constant from the first position
		int wait = Integer.parseInt(strings.get(0));
		
		// Do some stuff to isolate arrival times
		ArrayList<String> doStuff = new ArrayList<String>();
		for (String s : strings) {
			if (s.startsWith("ARRIVAL-TIME")) {
				doStuff.add(s);
			}
		}
		
		// Once arrival times are isolated, make nodes for LinkedList
		for (int i=0; i<doStuff.size(); i++) {
			
			int id = i+1;
			String arrival = doStuff.get(i).strip();
			int index = arrival.indexOf(':');
			arrival = arrival.substring(index+2);
			
			// Create node (add to list using FIFO method!)
			CNode node = new CNode(id, arrival, wait);
			queue.addFirst(node);
		}	
		
		// Reverse the queue before returning - 
		// Since we used an addFirst method, the queue is in
		// descending order, but we want ascending order
		queue.first = queue.reverse(queue.first);
		return queue;
	}
	
	/**
	 * Prints the array in a nice format
	 * @param arr The ArrayList to print
	 */
	public void printArray(ArrayList<String> arr) {
		
		for (String s : arr) {
			System.out.println(s);
		}
	}
	
	/**
	 * Prints nodes in a nice format
	 */
	public void printNodes(CQueue<CNode> nodes) {
		
		if (!nodes.isEmpty()) {
			
			CNode current = nodes.first;
			while (current != null) {
				
				System.out.println("Customer: " + current.id);
				System.out.println("\tArrival time: " + current.time);
				System.out.println("\tMath: " + current.startTime + " + "
						+ current.wait + " = " + current.endTime);
				
				current = current.next;
			}
		}
		else {
			System.out.println("Queue is empty.");
		}
	}
}
