/**
 * Class that makes a Customer node to be used in a LinkedList
 * 
 * @author grahamharris
 */
public class CNode {

	TimeCalculations calc = new TimeCalculations();
	
	String time;
	int wait = 0; // everyone starts with a 0 wait time
	int serviceTime, startTime, endTime, id;
	CNode next = null;
	
	//--------------------------------------
	
	// Default constructor
	public CNode() {
		this.id = 0;
		this.time = "9:00:00";
	}
	
	// Proper constructor
	public CNode(int i, String t, int serviceTime) {
		this.id = i;
		this.time = t;
		this.serviceTime = serviceTime;
		this.startTime = calc.convertSeconds(t);
		before9(this.startTime);
		this.endTime = addWaitTime();
		this.wait = endTime - startTime;
	}
	
	//--------------------------------------
	
	/**
	 * Changes the wait time to 9 am if the customer arrives before 9
	 * @param startTime Original arrival time of customer
	 */
	public void before9(int startTime) {
		if (startTime < 32400) {
			this.wait = 32400 - startTime;
			this.startTime = 32400;
		}
	}
	
	/**
	 * Adds n seconds to the wait and end times of the customer
	 * @param n Number of waiting seconds
	 */
	public void addToEndTime(int n) {
		this.endTime += n;
		this.wait += n;
	}

	/**
	 * Adds the wait time elapsed to the clock of the customer
	 * @param time Arrival time of customer
	 * @param serviceTime Amount of time (in seconds) spent waiting
	 * @return Time after customer has been served
	 */
	public int addWaitTime() {
		
		int total = this.startTime + this.serviceTime;
		
		return total;
	}
	
	/**
	 * Calculates the proper wait time
	 * @return Wait time
	 */
	public int calcWait() {
		
		TimeCalculations calc = new TimeCalculations();
		
		wait = startTime - calc.convertSeconds(this.time);
		System.out.println(startTime + ", " + calc.convertSeconds(this.time));
		return wait;
		
	}
	
}
