import java.io.*;
import java.util.*;

/**
 *  Contains main method where program is run. When this program is called
 *  from the command line, the program should take in 2 arguments for the
 *  two text files, then perform analysis and return the requested information
 *  in the specified format.
 * 
 * @author grahamharris
 */
public class Program {
	
	public static void main(String[] args) {
		
		ArgsValidation valid = new ArgsValidation(); // Instantiate objects
		Operator operator = new Operator();          // needed to start program
		
		if (args.length == 2) { // Check if we have the right number of args
			
			if (valid.goodData(args[0], args[1])) { // If good data....
				
				// (swap args if they're in the wrong order though)
				if (!valid.correctOrder(args[0], args[1])) {
					String temp = args[0]; args[0] = args[1]; args[1] = temp; }
				
				try { // ... try to find the filenames, then start the program:
					// Read the files
					BufferedReader customersFile = new BufferedReader(new FileReader(args[0]));
					BufferedReader queriesFile = new BufferedReader(new FileReader(args[1]));
					
					// Split the files into easily-readable ArrayLists
					ArrayList<String> customersArr = new ArrayList<String>();
					customersArr = operator.splitFile(customersFile);
					ArrayList<String> queries = new ArrayList<String>();
					queries = operator.splitFile(queriesFile);
					
					// Make a Queue (CQueue) of customers (CNodes)
					CQueue<CNode> queue = new CQueue<CNode>();
					queue = operator.makeQueue(customersArr);
					
					// Do some math on the start times so
					// that they accurately reflect the queue
					Answers answers = new Answers(queue, queries);
					answers.accurateStartTimes();
					
					// Print the answers!
					answers.printAnswers(); }
				
				// If the files don't exist...
				catch(FileNotFoundException e) { System.out.println(
						"Something went wrong trying to find the files."); }
			}
		}
		// If the program isn't supplied the right amount of arguments
		else { System.out.println("An incorrect number of "
				+ "arguments were supplied to this program. "
					+ "Please enter 2 arguments."); }
	}
}
