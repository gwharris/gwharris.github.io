/**
 * A queue of customers, functions like a LinkedList but following the
 * first-in, first-out method. I didn't include a dequeue method 
 * because this program considers a customer "served" if their
 * start time 
 * 
 * @author grahamharris
 */
public class CQueue<T> {

	CNode first;
	
	//--------------------------
	
	// Empty queue constructor
	public CQueue() {
		
		first = null;
		
	}
	
	//--------------------------
	
	/**
	 * Checks if Queue is empty.
	 * @return True if empty, false if not
	 */
	public boolean isEmpty() {
		return this.first == null;
	}
	
	/**
	 * Add method that adds first. This is "LIFO" so we need
	 * to reverse the queue later if we use this add method.
	 * @param node Node to add
	 * @return Node
	 */
	public CNode addFirst(CNode node) {
		
		CNode temp = first;
		first = node;
		node.next = temp;
		
		return node;
		
	}
	
	/**
	 * Method that prints a CQueue in a nice format
	 */
	public void printQueue() {
		
		if (!isEmpty()) {
			
			CNode current = this.first;
			while (current != null) {
				System.out.println("Customer " + current.id + ":" 
						+ "\nArrival time:\t" + current.time
						+ "\nStart time:\t" + current.startTime);
				
				current = current.next;
			}
		}
		else {
			System.out.println("The queue is empty.");
		}
	}
	
	/**
	 * Allows user to search for a node by customer number
	 * @param search
	 * @return
	 */
	public CNode find(int customer) {
		
		if (!isEmpty()) {
			
			CNode current = this.first;
			while (current != null) {
				if (current.id == customer) {
					return current;
				}
				current = current.next;
			}
		}
		System.out.println("Could not find that node.");
		return null;
		
	}
	
	/**
	 * Method returns number of elements in queue
	 */
	public int count() {
		
		int counter = 0;
		if (!isEmpty()) {
			CNode current = this.first;
			while (current != null) {
				counter ++;
				current = current.next;
			}
		}
		return counter;
	}
	
	/**
	 * Reverses queue
	 */
	public CNode reverse(CNode node) { 
        CNode prev = null; 
        CNode current = node; 
        CNode next = null; 
        
        while (current != null) { 
            next = current.next; 
            current.next = prev; 
            prev = current; 
            current = next; 
        } 
        node = prev; 
        return node; 
    }
}
