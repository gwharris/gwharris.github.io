import java.io.*;
import java.util.*;

/**
 * Homework 1
 * 
 * Course registry system
 * User logs in and sees options based on username and password. Admins can
 * perform admin functions and students can perform student functions.
 * 
 * @author grahamharris
 */
public class Application {

	public static void main(String[] args) throws IOException {

		// These are arraylists for the student and course objects we'll instantiate
		ArrayList<Course> courses = new ArrayList<Course>();
		ArrayList<Student> students = new ArrayList<Student>();
		
		// Create string arrays of all the commands admins and students can enter
		String[] adminActions = {
				"Create Course",
				"Delete Course",
				"Edit Course",
				"Display Course by ID",
				"Register New Student",
				"View All Courses",
				"View Filled Courses",
				"Export Filled Courses List",
				"View Registered Students by Course ID",
				"View Student by Student Username",
				"Sort Classes by # Registered Students",
				"Exit"
		};
		String[] studentActions = {
				"View All Courses",
				"View Available Courses",
				"Register",
				"Withdraw",
				"My Courses",
				"Exit"
		};
		
		/**
		 * START PROGRAM ---------------------------------------------
		 */
		
		// Reading file
		// ---------------------------------------------
		// Variables necessary for reading file
		
		ArrayList<String> file = new ArrayList<String>();
		String line = "";
		int counter = 0;
		
		// ---------------------------------------------
		// Try to read from the .ser file
		// Syntax for FileInputStream found online at https://www.tutorialspoint.com/java/java_serialization.htm
		try {
	         FileInputStream fileIn = new FileInputStream("CourseRegistry.ser");
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         Data deserialized = (Data) in.readObject();
	         
	         // If we find a data object, add the data fields
	         courses = deserialized.getCourses();
	         students = deserialized.getStudents();
	         
	         System.out.println("Welcome to Course Registry!\n");
	         
	         in.close();
	         fileIn.close();
	      } 
		
		catch (ClassNotFoundException e ){
			System.out.println("Something went wrong when resolving the list of students and courses."
					+ " Please try again.");
			e.printStackTrace();
		}
		
		// Failed to read .ser
		catch (FileNotFoundException c) {
			System.out.println("Welcome to Course Registry!\n"
					+ "This seems like your first time running the program.");
			
			// Try to read .csv
			try {
				FileReader fileReader = new FileReader("MyUniversityCourses.csv");
				BufferedReader bufferedReader = new BufferedReader(fileReader);
				while((line = bufferedReader.readLine()) != null) {
					String readline = bufferedReader.readLine();
					file.add(readline);
				
			// ---------------------------------------------
			// Array list of courses
					
					String[] split = readline.split(",");
				
					int intMaxStud = Integer.parseInt(split[2]);
					int intCurStud = 0;
					int courseLoc = Integer.parseInt(split[6]);
					ArrayList<Student> listStudents = new ArrayList<Student>();
					
					Course course = new Course(split[0], split[1], intMaxStud, intCurStud, listStudents, split[5], courseLoc, split[6]);
				
					courses.add(course);
					
				}
				bufferedReader.close();
			}
			
			// Failed to read .csv
			catch (FileNotFoundException ex){
				System.out.println("The system could not connect to a data set. "
						+ "Please try again or move the data set to the "
						+ "proper location.");
			}
		}
		
		// ---------------------------------------------
		// ---------------------------------------------
		// Welcome user to program, get input for student or admin
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	
		System.out.println("Are you a student or an admin? Please enter "
				+ "\"1\" for admin or \"2\" for student.");
		
		// ---------------------------------------------
		// We assume the user gave us bad input
		
		boolean badInput = true;
		String user = "";
		int userInt = 0;
		
		while (badInput) {
			user = in.readLine();
			
			try { 
				userInt = Integer.parseInt(user); 
				// Assign "1" to admins, "2" to students
					if (userInt == 1 || userInt == 2) {
						badInput = false;
					}
					else {
						System.out.println("Please only enter the number \"1\" for admin or \"2\" for student.");
					}
				}
			catch (Exception e) {
				System.out.println("Sorry, I couldn't understand that. "
						+ "Please enter \"1\" for admin or \"2\" for student.\n");
			}
		}
		
		
		// ---------------------------------------------
		// Now let's differentiate between Student or Admin:
		
		Admin admin = new Admin();
		
		// Validate Admin ------------------------------
		if (userInt == 1) {
			System.out.println("Please enter the admin username.");
			String username = in.readLine();
			// Admin Username
			if (username.toLowerCase().equals(admin.getUsername())) {
				System.out.println("Please enter the admin password.");
				String password = in.readLine();
				// Admin Password
				if (password.toLowerCase().equals(admin.getPassword())) {
					
					// Print list of actions
					System.out.println("Welcome, admin! Here is a list of functions you can perform. ");
					
					for (int i=0; i<adminActions.length; i++) {
						System.out.println((i+1) + ".\t" + adminActions[i]);
					}
					
					boolean flag = true;
					
					// Allow user to enact decisions
					while (flag) {
						int option = 0;
						System.out.println("\nPlease input the number of the action you would like to perform."
								+ "\nPress the \"enter\" key to see the list of actions again.");
						try {
							option = Integer.parseInt(in.readLine());
						}
						catch (Exception e) {
							
						}
						
						switch (option) {
						
						// Display options again
							case(0) :
								for (int i=0; i<adminActions.length; i++) {
									System.out.println((i+1) + ".\t" + adminActions[i]);
								}
								break;
								
						// Create course
							case(1) : 
								Course course = admin.create();
								courses.add(course);
								System.out.println("Course added!");
								break;
								
						// Delete course
							case(2) :
								courses = admin.delete(courses);
								break;
							
						// Edit course
							case(3) :
								courses = admin.edit(courses);
								break;
							
						// Display course by ID
							case(4) : admin.displayID(courses);
								break;
							
						// Register new Student object
							case(5) :
								students.add(admin.registerStudent());
								break;
							
						// View all
							case(6) :
								admin.viewAll(courses);
								break;
							
						// View full
							case(7) :
								admin.viewFullClasses(courses);
								break;
							
						// Write to file
						/**
						 * NOTE:
						 * This command will write to a file within the folder
						 * that this program is running in!! I'm not sure
						 * how to get this file to download into a user's
						 * "downloads" folder in Unix/Linux/OS.
						 */
							case(8) :
								admin.writeFile(courses);
								break;
							
						// View students in course
							case(9) :
								admin.viewStudentsInCourse(courses, students);
								break;
							
						// View students registered in a given course
							case(10) :
								admin.viewStudentRegistered(courses);
								break;
							
						// Sort classes by number of students registered
							case(11) :
								try {
									courses = admin.sortByStudent(courses, courses.size(), 0, courses.size()-1);
									admin.viewAll(courses);
								}
								catch (StackOverflowError e) {
									System.out.println("Something is wrong with the sort function "
											+ "(Stack Overflow), cannot return a sorted list.");
								}
								break;
							
						// Exit program
							case(12) : 
								flag = false;
								System.out.println("Logging out. See you next time!");
								break;
						
						// Default
							default : System.out.println("Sorry, that wasn't a valid number.");
						}	
					}
				}
				else {
					System.out.println("You've entered an incorrect password.");
				}
			}
			// If an incorrect username was entered
			else {
				System.out.println("You've entered an incorrect username. "
						+ "Please try again.");
			}
		}
		
		// Validate Student ------------------------------
		
		else if (userInt == 2) {
			
			System.out.println("Please enter your username.");
			String username = in.readLine();
			
			for (Student s : students) {
				// Student Username
				if (s.getUsername().equals(username)) {
					
					System.out.println("Please enter your password.");
					String password = in.readLine();
					// Student Password
					if (s.getPassword().equals(password)) {
						
						System.out.println("Welcome, " + s.getFirstName() + "! Here is a list of functions you can perform. ");
						
						// Print list of actions
						for (int i=0; i<studentActions.length; i++) {
							System.out.println((i+1) + ".\t" + studentActions[i]);
						}
						
						boolean flag = true;
						
						// Allow user to enact decisions
						while (flag) {
							int option = 0;
							System.out.println("\nPlease input the number of the action you would like to perform."
									+ "\nPress the \"enter\" key to see the list of actions again.");
							try {
								option = Integer.parseInt(in.readLine());
							}
							catch (Exception e) {
								
							}
							
							switch (option) {
							
							// Display options again
								case(0) :
									for (int i=0; i<studentActions.length; i++) {
										System.out.println((i+1) + ".\t" + studentActions[i]);
									}
									break;
									
							// View all courses
								case(1) :
									s.viewAll(courses);
									break;
									
							// View open courses
								case(2) :
									s.openCourseView(courses);
									break;
								
							// Register
								case(3) :
									s.registerForCourse(courses);
									break;
								
							// Withdraw
								case(4) :
									s.withdraw(courses);
									break;
								
							// View courses
								case(5) :
									s.viewRegisteredCourses();
									break;
								
							// Exit
								case(6) : 
									flag = false;
									System.out.println("Logging out. See you next time!");
									break;
									
							// Default
								default : System.out.println("Sorry, that wasn't a valid number.");
							}
						}
						
					}
					else {
						System.out.println("Sorry, that password is incorrect.");
					}
				}
				else {
					System.out.println("Sorry, that username does not exist.");
				}
			}
		}
		// Close BufferedReader
		in.close();
		
		// Save data to serialize
		Data data = new Data(students, courses);
		
		// Try serialization
		// Syntax for FileOutputStream found online at https://www.tutorialspoint.com/java/java_serialization.htm
		try {
	         FileOutputStream fileOut = new FileOutputStream("CourseRegistry.ser");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(data);
	         out.close();
	         fileOut.close();
	         System.out.printf("\nSerialized data is saved in CourseRegistry.ser file.");
	      } 
		// If it fails...
		catch (IOException e) {
			System.out.println("OH NO! The data could not be serialized. "
					+ "Unfortunately, data has not been saved.");
			e.printStackTrace();
		}
	}
}
