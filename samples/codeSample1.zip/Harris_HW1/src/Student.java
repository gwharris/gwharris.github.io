import java.io.*;
import java.util.*;

/**
 * Student objects - each student inherits from user
 * and contains methods from the Student interface.
 * 
 * @author grahamharris
 */
public class Student extends User implements StudentInterface, java.io.Serializable {

	// Instance variables
	
	/**
	 * Default Serial Version UID
	 */
	private static final long serialVersionUID = 1L;
	
	private String username, password, firstName, lastName;
	private ArrayList<Course> studCourses;
	
	// ---------------------------------------------
	// Constructor
	
	public Student() {
		
	}
	
	public Student(String username, String password, String firstName, String lastName) {
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		
		studCourses = new ArrayList<Course>();
		
	}
	
	// ---------------------------------------------
	// Methods
	
	/**
	 * Allows student to view courses that are open for registry
	 * @param Course list from main function
	 */
	public void openCourseView(ArrayList<Course> courses) {
		
		System.out.println("The following courses are available: ");
		
		boolean hasntPrinted = true;
		
		for (Course c : courses) {
			if (c.getMaxStudents() != c.getCurrentStudents()) {
				System.out.println(c.getCourseName());
				hasntPrinted = false;
			}
		}
		if (hasntPrinted) {
			System.out.println("All courses are full.");
		}
		
	}
	
	/**
	 * Allows student to register in courses
	 * @return Returns the new ArrayList of courses
	 * @param Course list from main function
	 */
	public void registerForCourse(ArrayList<Course> courses) {
		
		String courseID = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the ID of the course you'd like to enter: ");
		try {
			courseID = in.readLine();
		} catch (IOException e) {
			System.out.println("Sorry, I couldn't quite understand that.");
		}
		
		boolean flag = true;
		for (Course c : courses) {
			if (courseID.equals(c.getCourseID()) && c.getCurrentStudents() != c.getMaxStudents()) {
				studCourses.add(c);
				c.setCurrentStudents(c.getCurrentStudents() + 1);
				System.out.println("You have been added to " + courseID + "!");
				flag = false;
			}
			else if (c.getCurrentStudents() == c.getMaxStudents()) {
				System.out.println("The course " + courseID + " is full - you have not been registered.");
				flag = false;
			}
		}
		if (flag) {
			System.out.println("Error: could not register for class.");
		}
	}

	/**
	 * Allows student to withdraw from courses
	 * @return Returns the new ArrayList of courses
	 * @param Course list from main function
	 */
	public void withdraw(ArrayList<Course> courses) {
	
		String courseID = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the ID of the course you'd like to withdraw from: ");
		try {
			courseID = in.readLine();
		} catch (IOException e) {
			System.out.println("Sorry, I couldn't quite understand that.");
		}
		
		for (Course c : courses) {
			if (courseID.equals(c.getCourseID()) && c.getCurrentStudents() != c.getMaxStudents()) {
				studCourses.remove(c);
				c.setCurrentStudents(c.getCurrentStudents() - 1);
				System.out.println("You have been removed from " + courseID + ".");
			}
		}
	}
	
	/**
	 * Allows a student to view registered courseload
	 */
	public void viewRegisteredCourses() {
		
		for (Course c : this.studCourses) {
			System.out.println(c.getCourseName());
		}
	}
	
	// Getters and Setters

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the studCourses
	 */
	public ArrayList<Course> getStudCourses() {
		return studCourses;
	}

	/**
	 * @param studCourses the studCourses to set
	 */
	public void setStudCourses(ArrayList<Course> studCourses) {
		this.studCourses = studCourses;
	}
	
	
	
}
