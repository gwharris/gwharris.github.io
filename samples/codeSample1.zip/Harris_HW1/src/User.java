import java.util.*;

/**
 * Base class for all users (Admin and User). Common methods,
 * such as viewing all courses, are shared. There are also common
 * getters and setters for username, password, first name, and last name.
 * 
 * @author grahamharris
 */
public abstract class User {

	// Instance Variables
	
	private String username, password, firstName, lastName = "";
	
	// ---------------------------------------------
	// Constructors

	/**
	 * Default constructor
	 */
	public User() {
		
	}
	
	/**
	 * Constructor for Admins.
	 * @param username Username
	 * @param password Password
	 */
	public User(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	/**
	 * Constructor for Students.
	 * @param username Username
	 * @param password Password
	 * @param firstName Student's first name
	 * @param lastName Student's last name
	 */
	public User(String username, String password, String firstName, String lastName) {
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	// ---------------------------------------------
	// Getters and Setters
	
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastname the lastname to set
	 */
	public void setLastName(String lastname) {
		this.lastName = lastname;
	}

	// ---------------------------------------------
	// Methods
	
	/**
	 * Allows any user to view total list of courses
	 * @param courses List of courses
	 */
	public void viewAll(ArrayList<Course> courses) {
		
		for (Course c : courses) {
			System.out.println(c.getCourseName() + ", " + c.getCourseID() + ", " + 
					c.getCurrentStudents() + ", " + c.getInstructor() + ", " + 
					c.getCourseSection() );
		}
		
	}
	
}
