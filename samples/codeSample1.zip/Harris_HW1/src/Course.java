import java.util.*;

/**
 * Course objects class - allows classes to be
 * instantiated with the given class fields.
 * 
 * @author grahamharris
 */
public class Course implements java.io.Serializable {

	// Instance Variables
	
	/**
	 * Default Serial Version UID
	 */
	private static final long serialVersionUID = 1L;
	
	private String courseName, courseID, instructor, courseLocation;
	private int maxStudents, currentStudents, courseSection;
	private ArrayList<Student> listStudents;
	
	// ---------------------------------------------
	// Constructors
	
	public Course() {
		
	}
	
	public Course(String courseName, String courseID, int maxStudents, 
			int currentStudents, ArrayList<Student> listStudents, String instructor,  
			int courseSection, String courseLocation) {
		
		this.courseName = courseName;
		this.courseID = courseID;
		this.courseLocation = courseLocation;
		this.instructor = instructor;
		this.maxStudents = maxStudents;
		this.currentStudents = currentStudents;
		this.courseSection = courseSection;
		this.listStudents = listStudents;
		
	}

	// ---------------------------------------------
	// Getters and Setters
	
	/**
	 * @return the courseName
	 */
	public String getCourseName() {
		return courseName;
	}

	/**
	 * @param courseName the courseName to set
	 */
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	/**
	 * @return the courseID
	 */
	public String getCourseID() {
		return courseID;
	}

	/**
	 * @param courseID the courseID to set
	 */
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}

	/**
	 * @return the instructor
	 */
	public String getInstructor() {
		return instructor;
	}

	/**
	 * @param instructor the instructor to set
	 */
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

	/**
	 * @return the courseLocation
	 */
	public String getCourseLocation() {
		return courseLocation;
	}

	/**
	 * @param courseLocation the courseLocation to set
	 */
	public void setCourseLocation(String courseLocation) {
		this.courseLocation = courseLocation;
	}

	/**
	 * @return the maxStudents
	 */
	public int getMaxStudents() {
		return maxStudents;
	}

	/**
	 * @param maxStudents the maxStudents to set
	 */
	public void setMaxStudents(int maxStudents) {
		this.maxStudents = maxStudents;
	}

	/**
	 * @return the currentStudents
	 */
	public int getCurrentStudents() {
		return currentStudents;
	}

	/**
	 * @param currentStudents the currentStudents to set
	 */
	public void setCurrentStudents(int currentStudents) {
		this.currentStudents = currentStudents;
	}

	/**
	 * @return the courseSection
	 */
	public int getCourseSection() {
		return courseSection;
	}

	/**
	 * @param courseSection the courseSection to set
	 */
	public void setCourseSection(int courseSection) {
		this.courseSection = courseSection;
	}

	/**
	 * @return the listStudents
	 */
	public ArrayList<Student> getListStudents() {
		return listStudents;
	}

	/**
	 * @param listStudents the listStudents to set
	 */
	public void setListStudents(ArrayList<Student> listStudents) {
		this.listStudents = listStudents;
	}
	
	// ---------------------------------------------
	// Methods
	
	/**
	 * Allows student to be added to course
	 * @param student
	 */
	public void addStudent(Student student) {
		listStudents.add(student);
	}
	
	/**
	 * Allows student to be removed from course
	 * @param student
	 */
	public void removeStudent(Student student) {
		listStudents.remove(student);
	}
	
}