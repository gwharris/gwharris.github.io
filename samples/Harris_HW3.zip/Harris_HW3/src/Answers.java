import java.util.*;

/**
 * Class that answers the query questions in the homework
 * 
 * @author grahamharris
 */
public class Answers {

	CQueue<CNode> nodes;
	ArrayList<String> queries;
	
	public Answers(CQueue<CNode> nodes, ArrayList<String> queries) {
		this.nodes = nodes;
		this.queries = queries;
	}
	
	/**
	 * Computes proper wait times for each customer
	 * @param nodes
	 **/
	public void accurateStartTimes() {
		
		CNode current = nodes.first;
		
		// While there are nodes
		while (current.next != null) {
			
			CNode next = current.next;
				
			// Change the wait time of the next person
			// and the startTime to reflect when this person ends
			if (current.endTime > next.startTime) {
				next.wait += (current.endTime - next.startTime);
				next.startTime = current.endTime;
				next.addWaitTime();
					
			}
			current = next;
		}
	}
	
	/**
	 * Calculates the longest break the employee has.
	 * Code is very similar to "accurateStartTimes" but
	 * differs where the calculation is performed
	 * @param queue Queue to work with
	 */
	public int maxBreak() {
		
		int counter = 0;
		CNode current = nodes.first;
		
		// While there are nodes
		while (current.next != null) {
			
			CNode next = current.next;
				
			// Calculate the wait time between each person
			if (current.endTime <= next.startTime) {
				int x = next.startTime - current.endTime;
				if (x > counter) {
					counter = x;
				}
					
			}
			current = next;
		}
		return counter;
	}
	
	/**
	 * Calculates total idle time of employee.
	 * Code is very similar to "maxBreak" but
	 * the wait times are added instead of returned
	 * @param queue Queue to work with
	 * @return Total idle time
	 */
	public int totalIdle() {
		
		int counter = 0;
		CNode current = nodes.first;
		
		// While there are nodes
		while (current.next != null) {
			
			CNode next = current.next;
				
			// Calculate the wait time between each person
			if (current.endTime <= next.startTime) {
				counter += next.startTime - current.endTime;
					
			}
			current = next;
		}
		return counter;
	}
	
	/**
	 * Calculates number of served customers.
	 * Code is very similar to "totalIdle" but determines
	 * if the person is served before 5pm instead.
	 * @param queue Queue to work with
	 * @return Number of customers served
	 */
	public int numberServed() {
		
		int counter = 0;
		CNode current = nodes.first;
		
		// While there are nodes
		while (current.next != null) {
				
			// Calculate the start time of each person
			// If start time is before 5pm...
			if (current.startTime < 61200) {
				counter ++;
			}
			
			if (current.next != null) {
				CNode next = current.next;
				current = next;
			}
		}
		return counter;
	}
	
	/**
	 * Find the longest line of people who are served directly
	 * one after the other.
	 * @param queue Queue to work with
	 * @return Max number of people in line
	 */
	public int maxInQueue() {
		
		int counter = 0;
		int[] ints = new int[1];
		CNode current = nodes.first;
		
		// While there are nodes
		while (current.next != null) {
			
			CNode next = current.next;
			
			// Calculate the wait time between each person
			if (current.endTime == next.startTime) {
				counter++;
			}
			
			// If we break the streak, we need to add the counter
			// to the ints array, then make a new array for the next
			// iteration of the while loop of size + 1. This way, at the end,
			// we'll have an array that is 1 larger than what we need, but
			// the last value is set to 0, it won't matter in the end.
			else if (current.endTime < next.startTime) {
				ints[ints.length-1] = counter;
				int[] newArray = new int[ints.length + 1];
				
				for (int i=0; i<ints.length; i++) {
					
					newArray[i] = ints[i];
					newArray[i+1] = 0;
				}
				
				ints = newArray;
				counter = 0;
				
			}
			current = next;
		
		}
		
		// Cycle through our new array to find the maximum
		int max = 0;
		for (int j=0; j<ints.length; j++) {
			if (ints[j] > max) {
				max = ints[j];
			}
		}
		
		return max;
		
	}
	
	/**
	 * Prints answers to questions in the output.txt format
	 */
	public void printAnswers() {
		
		// Print the answers!
		System.out.print(queries.get(0) + ":");
		System.out.println(numberServed());
		System.out.print(queries.get(1) + ":");
		System.out.println(maxBreak());
		System.out.print(queries.get(2) + ":");
		System.out.println(totalIdle());
		System.out.print(queries.get(3) + ":");
		System.out.println(maxInQueue());
		System.out.print(queries.get(4) + ":");
		System.out.println(nodes.find(1).calcWait());
		System.out.print(queries.get(5) + ":");
		System.out.println(nodes.find(2).calcWait());
		System.out.print(queries.get(6) + ":");
		System.out.println(nodes.find(3).calcWait());
		System.out.print(queries.get(7) + ":");
		System.out.println(nodes.find(7).calcWait());
		
	}
	
}
	
	
	
