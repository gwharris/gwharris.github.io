

/**
 * Class that does necessary calculations for the program
 * 
 * @author grahamharris
 */
public class TimeCalculations {

	// Variables that represent time
	int minPerHour = 60;
	int secPerMin = 60;
	
	/**
	 * Converts from hours, minutes, and seconds to only seconds
	 * @param time Time in hours, minutes, and seconds
	 * @return Time in seconds
	 */
	public int convertSeconds(String time) {
		
		String[] strings = time.split(":");
		int h = Integer.parseInt(strings[0]);
		int m = Integer.parseInt(strings[1]);
		int s = Integer.parseInt(strings[2]);
		
		int totalSeconds = s;
		
		// If hours < 5 pm, then its the afternoon:
		if (h < 6) {
			h += 12;
		}
		
		totalSeconds = totalSeconds + (h * minPerHour * secPerMin);
		totalSeconds = totalSeconds + (m * secPerMin);
		
		return totalSeconds;
	}
	
	/**
	 * Convert from seconds to hours, minutes, seconds
	 * @param s Total seconds
	 * @return Time in hours, minutes, seconds
	 */
	public String convertHMS(int s) {
		
		int m = s / secPerMin;
		s = s % secPerMin;
		
		int h = m / minPerHour;
		m = m % minPerHour;
		
		// If its afternoon...
		if (h > 13) {
			h -= 12;
		}
		
		String string = String.valueOf(h) + ":" + String.valueOf(m) + 
				":" + String.valueOf(s);
		
		return string;
	}
	
}
