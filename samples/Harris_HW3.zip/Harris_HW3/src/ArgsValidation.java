import java.io.*;

/**
 * Class that validates arguments
 * 
 * @author grahamharris
 */
public class ArgsValidation {

	/**
	 * Checks if the arguments supplied are strings
	 * @param one First object
	 * @param two Second object
	 * @return True if objects are strings, false if not
	 */
	private boolean argsAreStrings (Object one, Object two) {
		
		// If args are strings, return true
		if (one instanceof String && two instanceof String) { return true; }
		
		// If args are not strings...
		System.out.println("The two arguments provided are not files. "
				+ "Please only input file names.");
		
		return false;
	}
	
	/**
	 * Validates if the arguments are files that exist in the program
	 * @param fileOne First file
	 * @param fileTwo Second file
	 * @return True if files exist, false if not
	 */
	private boolean filesExist (String fileOne, String fileTwo) {
		
		// Try to find the filenames using BufferedReaders, 
		// return true if found
		try {
			BufferedReader first = new BufferedReader(new FileReader(fileOne));
			BufferedReader second = new BufferedReader(new FileReader(fileTwo));
			return true;
		}
		// If the files don't exist...
		catch(FileNotFoundException e) {
			System.out.println("File not found: Improper file name entered.");
			return false;
		}
	}
	
	/**
	 * Combines "argsAreStrings" and "filesExist" into one method
	 * @param one First argument
	 * @param two Second argument
	 * @return Boolean true if the data is good, false if not
	 */
	public boolean goodData(Object one, Object two) {
		
		// If the args are strings,
		if (argsAreStrings(one,two)) {
			
			// and if the args are the correct filenames...
			if (filesExist( (String) one, (String) two) ) {
				return true;
			}
			System.out.println((String) one + " " + (String) two);
			
		}
		// If both conditions are not satisfied...
		return false;
		
	}
	
	/**
	 * Checks to make sure that the files are in the right order
	 * @param one First filename
	 * @param two Second filename
	 * @return Boolean true if correct order, false if not
	 */
	public boolean correctOrder(String one, String two) {
		
		// If the customer file is first, return true
		if (one.equals("customersfile.txt")) {
			return true;
		}
		// If not, we'll need to swap them in the main method
		return false;
		
	}
	
}
