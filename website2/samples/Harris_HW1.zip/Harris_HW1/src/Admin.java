import java.io.*;
import java.util.*;

/**
 * Admin objects - each student inherits from user
 * and contains methods from the Admin interface.
 * 
 * @author grahamharris
 */
public class Admin extends User implements AdminInterface {
	
	// Instance variables
	
	private String username = "admin";
	private String password = "admin001";
	
	// ---------------------------------------------
	// Constructor
	
	public Admin() {
		
	}
	
	// ---------------------------------------------
	// Methods
	
	/**
	 * Allows admin to create a course
	 * @return Returns a new course
	 */
	public Course create() {
		
		String name = "";
		String id = "";
		int max = 1;
		String instr = "";
		int sec = 1;
		String loc = "";
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		// Read input for each variable to assign
		
		System.out.println("Please enter the course name: ");
		try {
			name = in.readLine();
		} catch (IOException e) {
			
		}
		
		System.out.println("Please enter the course ID: ");
		try {
			id = in.readLine();
		} catch (IOException e) {

		}
		
		System.out.println("Please enter the maximum number of students: ");
		try {
			max = Integer.parseInt(in.readLine());
		} catch (IOException e) {
			
		}
		
		System.out.println("Please enter the instructor's name: ");
		try {
			instr = in.readLine();
		} catch (IOException e) {
			
		}
		
		System.out.println("Please enter the course section: ");
		try {
			sec = Integer.parseInt(in.readLine());
		} catch (IOException e) {
			
		}
		
		System.out.println("Please enter the course location: ");
		try {
			loc = in.readLine();
		} catch (IOException e) {
			
		}

		ArrayList<Student> studs = new ArrayList<Student>();
		Course course = new Course(name, id, max, 0, studs, instr, sec, loc);
		
		return course;
		
	}
	
	/**
	 * Allows the admin to delete a course
	 * @return Returns the new ArrayList of courses
	 * @param Course list from main function
	 */
	public ArrayList<Course> delete(ArrayList<Course> courses) {
		
		String courseID = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the ID of the course you'd like to delete: ");
		try {
			courseID = in.readLine();
		} catch (IOException e) {
			System.out.println("Sorry, I couldn't quite understand that.");
		}
		
		for (Course c : courses) {
			if (courseID.equals(c.getCourseID())) {
				courses.remove(c);
				System.out.println("Course " + courseID + " has been removed!");
				return courses;
			}
		}
		
		System.out.println("Error, could not delete a course " + courseID + ".");
		return courses;
		
	}
	
	/**
	 * Allows admin to edit one of the available courses
	 * @return Returns the new ArrayList of courses
	 * @param Course list from main function
	 */
	public ArrayList<Course> edit(ArrayList<Course> courses) {
		
		String courseID = "";
		int courseSect = 0;
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the ID of the course you'd like to edit: ");
		try {
			courseID = in.readLine();
		} catch (IOException e) {
			System.out.println("Sorry, I couldn't quite understand that.");
		}
		
		System.out.println("Please enter the section of the course you'd like to edit: ");
		try {
			courseSect = Integer.parseInt(in.readLine());
		} catch (IOException e) {
			System.out.println("Sorry, I couldn't quite understand that.");
		}
		
		for (Course c : courses) {
			if (courseID.equals(c.getCourseID()) && courseSect == c.getCourseSection()) {
				
				System.out.println("Which attribute would you like to edit?"
						+ "\n1.\tCourse Name"
						+ "\n2.\tInstructor"
						+ "\n3.\tCourse Location"
						+ "\n4.\tMaximum Number of Students"
						+ "\n5.\tCourse Section"
						+ "\nEnter \"0\" to exit.");
				
				int j = 0;
				
				try {
					j = Integer.parseInt(in.readLine());
				} catch (NumberFormatException e) {
					System.out.println("Sorry, that value wasn't a number. Try again.");
					e.printStackTrace();
				} catch (IOException e) {
					System.out.println("Something went wrong, please try again.");
					e.printStackTrace();
				}
				
				switch (j) {
					case(0): 
						System.out.println("Now exiting edit mode.");
						break;
					case(1):
						System.out.println("Please enter the new course name: ");
						try {
							c.setCourseName(in.readLine());
						} catch (IOException e) {
							System.out.println("Could not enter new course name.");
							e.printStackTrace();
						}
						break;
					case(2):
						System.out.println("Please enter the new instructor: ");
						try {
							c.setInstructor(in.readLine());
						} catch (IOException e) {
							System.out.println("Could not enter new instructor.");
							e.printStackTrace();
						}
						break;
					case(3):
						System.out.println("Please enter the new location: ");
						try {
							c.setCourseLocation(in.readLine());
						} catch (IOException e) {
							System.out.println("Could not enter new location.");
							e.printStackTrace();
						}
						break;
					case(4):
						System.out.println("Please enter the new maximum number of students: ");
						try {
							c.setMaxStudents(Integer.parseInt(in.readLine()));
						} catch (IOException e) {
							System.out.println("Could not enter new number.");
							e.printStackTrace();
						}
						break;
					case(5):
						System.out.println("Please enter the new section number: ");
						try {
							c.setMaxStudents(Integer.parseInt(in.readLine()));
						} catch (IOException e) {
							System.out.println("Could not enter new number.");
							e.printStackTrace();
						}
						break;
				}
			}
			else if (courseID.equals(c.getCourseID())) {
				System.out.println("Course section not found. Returning you to list of options.");
			}
		}
		return courses;
	}
	
	/**
	 * Allows admin to view a course by course ID
	 * @param Returns the new ArrayList of courses
	 */
	public void displayID(ArrayList<Course> courses) {
		
		String courseID = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the ID of the course you'd like to see: ");
		try {
			courseID = in.readLine();
		} catch (IOException e) {
			System.out.println("Sorry, I couldn't quite understand that.");
		}
		
		for (Course c : courses) {
			if (courseID.equals(c.getCourseID())) {
				System.out.println(c.getCourseName() + "," + c.getCourseID() + "," + c.getMaxStudents() + "," + 
						c.getCurrentStudents() + "," + c.getListStudents() + "," + c.getInstructor() + "," + 
						c.getCourseSection() + "," + c.getCourseLocation());
			}
		}
		
	}
	
	/**
	 * Registers a new student
	 * @return Returns the new ArrayList of courses
	 */
	public Student registerStudent() {
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		String firstName = "-";
		System.out.println("What is the student's first name?");
		try {
			firstName = in.readLine();
		} catch (IOException e) {
			System.out.println("Failed to read first name - default set to \"-\".");
			e.printStackTrace();
		}
		
		String lastName = "-";
		System.out.println("What is " + firstName + "'s last name?");
		try {
			lastName = in.readLine();
		} catch (IOException e) {
			System.out.println("Failed to read last name - default set to \"-\".");
			e.printStackTrace();
		}
		
		String username = "student";
		System.out.println("Please set a username for " + firstName + " " + lastName + ".");
		try {
			username = in.readLine();
		} catch (IOException e) {
			System.out.println("Failed to read username - default set to \"student\".");
			e.printStackTrace();
		}
		
		String password = "temp";
		System.out.println("Please set a password for " + firstName + " " + lastName + ".");
		try {
			password = in.readLine();
		} catch (IOException e) {
			System.out.println("Failed to read password - default set to \"temp\".");
			e.printStackTrace();
		}
		
		Student student = new Student(username, password, firstName, lastName);
		return student;
		
	}
	
	/**
	 * Allows admin to see all filled classes
	 * @param Course list from main function
	 */
	public void viewFullClasses(ArrayList<Course> courses) {
		
		System.out.println("The following courses are full: ");
		
		boolean hasntPrinted = true;
		
		for (Course c : courses) {
			if (c.getMaxStudents() == c.getCurrentStudents()) {
				System.out.println(c.getCourseName());
				hasntPrinted = false;
			}
		}
		if (hasntPrinted) {
			System.out.println("No courses are full.");
		}
		
	}
	
	/**
	 * Writes filled course list to file
	 * 
	 * NOTE:
	 * Text file will be created in wherever the program is being run from
	 * 
	 * @param Course list from main function
	 */
	public void writeFile(ArrayList<Course> courses) {
		
		Writer writer = null;

		try {
		    writer = new BufferedWriter(new OutputStreamWriter(
		          new FileOutputStream("FilledClasses.txt"), "utf-8"));
		    for (Course c : courses) {
				if (c.getMaxStudents() == c.getCurrentStudents()) {
					writer.write(c.getCourseName() + "\n");
				}
			}
		} catch (IOException ex) {
		    System.out.println("File exception found - could not write to file.");
		}
	}
	
	/**
	 * Allows admin to view all students in course
	 * @param Course list from main function
	 */
	public void viewStudentsInCourse(ArrayList<Course> courses, ArrayList<Student> students) {
		
		String courseID = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the ID of the course you'd like to see: ");
		try {
			courseID = in.readLine();
		} catch (IOException e) {
			System.out.println("Sorry, I couldn't quite understand that.");
		}
		
		for (Student s : students) {
			for (Course c : s.getStudCourses()) {
				if (courseID.equals(c.getCourseID())) {
					System.out.println(s.getFirstName() + " " + s.getLastName());
				}
			}
		}
	}
	
	
	/**
	 * Allows admin to view the courses a student has registered in
	 * @param Course list from main function
	 */
	public void viewStudentRegistered(ArrayList<Course> courses) {
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		String firstName = "-";
		System.out.println("What is the student's first name?");
		try {
			firstName = in.readLine();
		} catch (IOException e) {
			System.out.println("Failed to read first name.");
			e.printStackTrace();
		}
		
		String lastName = "-";
		System.out.println("What is " + firstName + "'s last name?");
		try {
			lastName = in.readLine();
		} catch (IOException e) {
			System.out.println("Failed to read last name.");
			e.printStackTrace();
		}
		
		for (Course c : courses) {
			ArrayList<Student> studs = c.getListStudents();
			for (Student s: studs) {
				
				if (s.getFirstName().equals(firstName) && s.getLastName().equals(lastName)) {
					System.out.println(c.getCourseName());
				}
			}
		}
	}
	
	/**
	 * Allows admin to sort classes by number of registered students
	 * @param Course list from main function
	 */
	public ArrayList<Course> sortByStudent(ArrayList<Course> courses, int size, int start, int end) {
		
		// Recursive sort method
		
		// Two ArrayLists and a midpoint variable
		ArrayList<Course> course = new ArrayList<Course>();
		ArrayList<Course> course2 = new ArrayList<Course>();
		double mid = (start + end) / 2;
		
		// Base Case
		if (size == 1) {
			course.add(courses.get(0));
			return course;
		}
		// Recursive case
		else {
			course = sortByStudent(courses, (int) size/2, start, (int) Math.floor(mid));
			course2 = sortByStudent(courses, (int) size/2, (int) Math.ceil(mid), end);
			
			course = merge(course, course2);
			return course;
		}

	}
	
	/**
	 * Merge method used in the recursive sortByStudent method. 
	 * This method combines the two ArrayLists into one.
	 * 
	 * @param arr1
	 * @param arr2
	 * @return
	 */
	public ArrayList<Course> merge(ArrayList<Course> arr1, ArrayList<Course> arr2) {
		
		ArrayList<Course> out = new ArrayList<Course>();
		 
		int i = 0, j = 0;
		
		while ( i < arr1.size() && j < arr2.size() ) {
			if ( arr1.get(i).getCurrentStudents() < arr2.get(j).getCurrentStudents() ) {
				out.add(arr1.get(i));
				i++;
			}
			else {
				out.add(arr2.get(j));
				j++;
			}
		}
		
		return out;
	}
	
	// ---------------------------------------------
	// Getters and Setters
	
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
}
