import java.io.*;
import java.util.*;

/**
 * Class that stores data to be serialized - this way, only
 * one Data object needs to be serialized whenever the program 
 * is reopened.
 * 
 * @author grahamharris
 */
public class Data implements java.io.Serializable {

	// Instance variables
	
	/**
	 * Default Serial Version UID
	 */
	private static final long serialVersionUID = 1L;
	
	private ArrayList<Student> students = new ArrayList<Student>();
	private ArrayList<Course> courses = new ArrayList<Course>();
	
	// ---------------------------------------------
	// Constructors
	
	public Data() {
		
	}
	
	public Data(ArrayList<Student> students, ArrayList<Course> courses) {
		this.courses = courses;
		this.students = students;
	}
	
	// ---------------------------------------------
	// Getters and Setters
	
	/**
	 * @return the students
	 */
	public ArrayList<Student> getStudents() {
		return students;
	}
	/**
	 * @param students the students to set
	 */
	public void setStudents(ArrayList<Student> students) {
		this.students = students;
	}
	/**
	 * @return the courses
	 */
	public ArrayList<Course> getCourses() {
		return courses;
	}
	/**
	 * @param courses the courses to set
	 */
	public void setCourses(ArrayList<Course> courses) {
		this.courses = courses;
	}
	
}
