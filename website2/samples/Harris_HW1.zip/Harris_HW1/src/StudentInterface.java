import java.util.*;

public interface StudentInterface {

	public void openCourseView(ArrayList<Course> courses);
	
	public void registerForCourse(ArrayList<Course> courses);
	
	public void withdraw(ArrayList<Course> courses);
	
	public void viewRegisteredCourses();
	
}
