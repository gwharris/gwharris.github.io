import java.util.ArrayList;

public interface AdminInterface {

	public Course create();
	
	public ArrayList<Course> delete(ArrayList<Course> courses);
	
	public ArrayList<Course> edit(ArrayList<Course> courses);
	
	public void displayID(ArrayList<Course> courses);
	
	public Student registerStudent();
	
	public void viewFullClasses(ArrayList<Course> courses);
	
	public void writeFile(ArrayList<Course> courses);
	
	public void viewStudentsInCourse(ArrayList<Course> courses, ArrayList<Student> students);
	
	public void viewStudentRegistered(ArrayList<Course> courses);
	
	public ArrayList<Course> sortByStudent(ArrayList<Course> courses, int size, int start, int end);
	
}
